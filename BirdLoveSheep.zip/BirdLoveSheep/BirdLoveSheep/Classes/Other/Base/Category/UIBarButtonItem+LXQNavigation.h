//
//  UIBarButtonItem+LXQNavigation.h
//  BirdLoveSheep
//
//  Created by LiXiqing on 16/9/23.
//  Copyright © 2016年 LiXiQing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (LXQNavigation)
+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action;
@end
