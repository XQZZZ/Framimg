//
//  LXQTabBarController.m
//  BirdLoveSheep
//
//  Created by LiXiqing on 16/9/23.
//  Copyright © 2016年 LiXiQing. All rights reserved.
//

#import "LXQTabBarController.h"
#import "LXQNewController.h"
#import "LXQMeViewController.h"
#import "LXQFriendTrendsController.h"
#import "LXQEssenceController.h"
#import "LXQTabBar.h"
#import "LXQNavigationController.h"
@implementation LXQTabBarController
/**
 * 当第一次使用这个类的时候会调用一次
 */
+(void)initialize
{
    // 通过appearance统一设置所有UITabBarItem的文字属性
    // 后面带有UI_APPEARANCE_SELECTOR的方法, 都可以通过appearance对象来统一设置
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrs[NSForegroundColorAttributeName] = [UIColor grayColor];
    
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSFontAttributeName] = attrs[NSFontAttributeName];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
}
- (void)viewDidLoad
{
    [super viewDidLoad];

    // 添加子控制器
    [self setupChildVc:[[LXQEssenceController alloc] init] title:@"精华" image:@"tabBar_essence_icon" selectedImage:@"tabBar_essence_click_icon"];
    
    [self setupChildVc:[[LXQNewController alloc] init] title:@"新帖" image:@"tabBar_new_icon" selectedImage:@"tabBar_new_click_icon"];
    
    [self setupChildVc:[[LXQFriendTrendsController alloc] init] title:@"关注" image:@"tabBar_friendTrends_icon" selectedImage:@"tabBar_friendTrends_click_icon"];
    
    [self setupChildVc:[[LXQMeViewController alloc] init] title:@"我" image:@"tabBar_me_icon" selectedImage:@"tabBar_me_click_icon"];
    
    [self setValue:[[LXQTabBar alloc]init] forKey:@"tabBar"];
    //在LXQTabBar类里设置
//    [self.tabBar setBackgroundImage:[UIImage imageNamed:@""]];
}

/**
 * 初始化子控制器
 */
- (void)setupChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    // 设置文字和图片
    vc.navigationItem.title = title;
    vc.tabBarItem.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];

    // 包装一个导航控制器, 添加导航控制器为tabbarcontroller的子控制器
    LXQNavigationController *nav = [[LXQNavigationController alloc]initWithRootViewController:vc];

    [self addChildViewController:nav];
}
@end
